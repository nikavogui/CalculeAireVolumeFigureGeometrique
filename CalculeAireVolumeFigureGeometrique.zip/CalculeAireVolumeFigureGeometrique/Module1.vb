﻿Module Module1

    Sub Main()
MENU1:
        Console.WriteLine("Calcul de l'Aire/Volume des Figures Géometrique")
        Console.WriteLine("1-Pour le calcul de l'Aire")
        Console.WriteLine("2-Pour le calcul du Volume")

        Dim i As Integer = Console.ReadLine()

        Select Case i
            Case 1
MENU3:
                Console.WriteLine("Vous avez choisi le Calcul de l'Aire")
                Console.WriteLine("--------Selectionnez la Figure Géometrique-----------")
                Console.WriteLine("          1-Calcul Aire d'un Rectangle")
                Console.WriteLine("          2-Calcul Aire d'un Carré")
                Console.WriteLine("          3-Calcul Aire d'un Disque")
                Console.WriteLine("          4-Calcul Aire d'un Triangle")
                Console.WriteLine("          5-Calcul Aire d'un Triangle Rectangle")
                Console.WriteLine("          6-Calcul Aire d'un Trapèze")
                Console.WriteLine("          7-Calcul Aire d'un Parallélogramme")
                Console.WriteLine("          8-Calcul Aire d'un Losange")
                Console.WriteLine("          9-Calcul Aire d'une Sphère")
                Dim choixFigureAire As Integer = Console.ReadLine()

                Select Case choixFigureAire
                    Case 1
                        Console.WriteLine("Entrer la Longueur du Rectangle")
                        Dim longueur As Double = Console.ReadLine()
                        Console.WriteLine("Entrer la Largeur du Rectangle")
                        Dim largeur As Double = Console.ReadLine()
                        Dim resultat As Double = longueur * largeur
MENU4:
                        Console.WriteLine("Aire du Rectangle de L=" & longueur & " et de l=" & largeur & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU4
                        End Select

                    Case 2
                        Console.WriteLine("Entrer le Coté du Carré")
                        Dim cote As Double = Console.ReadLine()
                        Dim resultat As Double = cote * cote
MENU5:
                        Console.WriteLine("Aire du Carré de C=" & cote & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU5
                        End Select
                    Case 3
                        Console.WriteLine("Entrer le Rayon du Disque")
                        Dim r As Double = Console.ReadLine()
                        Dim resultat As Double = 3.14 * r * r
MENU6:
                        Console.WriteLine("Aire du Disque de R=" & r & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU6
                        End Select

                    Case 4
                        Console.WriteLine("Entrer la Base du Triangle")
                        Dim b As Double = Console.ReadLine()
                        Console.WriteLine("Entrer la Hauteur du Triangle")
                        Dim h As Double = Console.ReadLine()
                        Dim resultat As Double = (b * h) / 2
MENU7:
                        Console.WriteLine("Aire du Triangle de Base=" & b & " et de Hauteur=" & h & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU7
                        End Select
                    Case 5
                        Console.WriteLine("Entrer la valeur du coté Opposé du Triangle Rectangle")
                        Dim o As Double = Console.ReadLine()
                        Console.WriteLine("Entrer la Valeur du coté Adjacent du Triangle Rectangle")
                        Dim a As Double = Console.ReadLine()
                        Dim resultat As Double = (a * o) / 2
MENU8:
                        Console.WriteLine("Aire du Triangle Rectangle de Coté Opposé=" & o & " et de Coté Adjacent=" & a & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU8
                        End Select
                    Case 6
                        Console.WriteLine("Entrer la Valeur de la Grande Base du Trapèze")
                        Dim gb As Double = Console.ReadLine()
                        Console.WriteLine("Entrer la Valeur de la Petite Base du Trapèze")
                        Dim pb As Double = Console.ReadLine()
                        Console.WriteLine("Entrer la Valeur de la Hauteur du Trapèze")
                        Dim h As Double = Console.ReadLine()
                        Dim resultat As Double = ((gb + pb) * h) / 2
MENU9:
                        Console.WriteLine("Aire du Trapèze de Grande Base=" & gb & " ,Petite Base=" & pb & " et de Hauteur=" & h & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU9
                        End Select
                    Case 7
                        Console.WriteLine("Entrer la Base du Parrallélogramme")
                        Dim b As Double = Console.ReadLine()
                        Console.WriteLine("Entrer la Hauteur du Parallélogramme")
                        Dim h As Double = Console.ReadLine()
                        Dim resultat As Double = b * h
MENU10:
                        Console.WriteLine("Aire du Parallélogramme de Base=" & b & " et de Hauteur=" & h & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU10
                        End Select
                    Case 8
                        Console.WriteLine("Entrer la Valeur du Grand Diagonal du Losange")
                        Dim gd As Double = Console.ReadLine()
                        Console.WriteLine("Entrer la Valeur du Petit Diagonal")
                        Dim pd As Double = Console.ReadLine()
                        Dim resultat As Double = (gd * pd) / 2
MENU11:
                        Console.WriteLine("Aire du Losange de Grand Diagonal=" & gd & " et de Petit Diagonal=" & pd & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU11
                        End Select
                    Case 9
                        Console.WriteLine("Entrer la Valeur du Rayon de la Sphère")
                        Dim r As Double = Console.ReadLine()
                        Dim resultat As Double = (4 * r * 3.14)
MENU12:
                        Console.WriteLine("Aire de la Sphère de Rayon=" & r & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU12
                        End Select
                    Case Else
MENU13:
                        Console.WriteLine("--------------Choix Invalide---------------")
                        Console.WriteLine("          1-Retour au Menu Precedent")
                        Console.WriteLine("          2-Retour au Menu Principal")
                        Console.WriteLine("          3-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU3
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU13
                        End Select
                End Select
            Case 2

                Console.WriteLine("Vous avez choisi le Calcul du Volume")
                Console.WriteLine("--------Selectionnez la Figure Géometrique-----------")
                Console.WriteLine("          1-Calcul Volume d'un Pavé Droit")
                Console.WriteLine("          2-Calcul Volume d'un Cube")
                Console.WriteLine("          3-Calcul Volume d'un Cylindre")
                Console.WriteLine("          4-Calcul Volume d'un  Cône")
                Console.WriteLine("          5-Calcul Volume d'une Boule")
                Dim choixFigureVolume As Integer = Console.ReadLine()
                Select Case choixFigureVolume
                    Case 1
                        Console.WriteLine("Entrer la Longueur du Pavé Droit")
                        Dim longueur As Double = Console.ReadLine()
                        Console.WriteLine("Entrer la Largeur du Pavé Droit")
                        Dim largeur As Double = Console.ReadLine()
                        Console.WriteLine("Entrer la Hauteur du Pavé Droit")
                        Dim h As Double = Console.ReadLine()
                        Dim resultat As Double = longueur * largeur * h
MENU14:
                        Console.WriteLine("Volume du Pavé Droit de Longueur=" & longueur & " ,Largeur=" & largeur & " et de Hauteur=" & h & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU14
                        End Select
                    Case 2
                        Console.WriteLine("Entrer la Valeur du Coté du Cube")
                        Dim c As Double = Console.ReadLine()
                        Dim resultat As Double = c * c * c
MENU15:
                        Console.WriteLine("Volume du Cube de Coté=" & c & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU15
                        End Select
                    Case 3
                        Console.WriteLine("Entrer la Valeur de Hauteur du Cylindre")
                        Dim h As Double = Console.ReadLine()
                        Console.WriteLine("Entrer le Rayon du Cylindre")
                        Dim r As Double = Console.ReadLine()
                        Dim resultat As Double = r * r * h * 3.14
MENU16:
                        Console.WriteLine("Volume du Cylindre de rayon=" & r & " et de hauteur=" & h & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU16
                        End Select
                    Case 4
                        Console.WriteLine("Entrer la Valeur de Hauteur du Cône")
                        Dim h As Double = Console.ReadLine()
                        Console.WriteLine("Entrer le Rayon du Cône")
                        Dim r As Double = Console.ReadLine()
                        Dim resultat As Double = (r * r * h) / 3
MENU17:
                        Console.WriteLine("Volume du Cône de rayon=" & r & " et de hauteur=" & h & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU17
                        End Select
                    Case 5
                        Console.WriteLine("Entrer la Valeur de Hauteur de la Boule")
                        Dim h As Double = Console.ReadLine()
                        Console.WriteLine("Entrer le Rayon de la Boule")
                        Dim r As Double = Console.ReadLine()
                        Dim resultat As Double = ((r * r * h) * 4) / 3
MENU18:
                        Console.WriteLine("Volume de la Boule de rayon=" & r & " et de hauteur=" & h & " est de " & resultat)
                        Console.WriteLine("          1-Retour au Menu Principal")
                        Console.WriteLine("          2-Quitter le Programme")
                        Dim back As Integer = Console.ReadLine()
                        Select Case back
                            Case 1
                                GoTo MENU1
                            Case 2
                                Stop
                            Case Else
                                GoTo MENU18
                        End Select
                End Select
            Case Else
MENU2:
                Console.WriteLine("------------Choix Invalide---------------")
                Console.WriteLine("          1-Retour au Menu")
                Console.WriteLine("          2-Quitter le Programme")
                Dim back As Integer = Console.ReadLine()
                Select Case back
                    Case 1
                        GoTo MENU1
                    Case 2
                        Stop
                    Case Else
                        GoTo MENU2
                End Select

        End Select
    End Sub

End Module
